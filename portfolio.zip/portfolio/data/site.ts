export const site = {
    name: "Dhyey Patel",
    title: "Software Engineer",
    location: "Detroit, MI",
    email: "dpatel48@emich.edu",
    socials: [
        { label: "GitHub", href: "https://github.com/Dhyey-Patel28" },
        { label: "LinkedIn", href: "https://www.linkedin.com/in/dhyey-patel-page/" },
    ],
};